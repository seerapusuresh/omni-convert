import test from "node:test";
import assert from "node:assert/strict";
import { detectSignature, parseCsv, csvToJson, jsonToCsv, possibleOutputs } from "../src/formats.js";

test("detects common image signatures", () => {
  assert.equal(detectSignature(Uint8Array.from([0x89, 0x50, 0x4e, 0x47])), "image/png");
  assert.equal(detectSignature(Uint8Array.from([0xff, 0xd8, 0xff])), "image/jpeg");
  assert.equal(detectSignature(Uint8Array.from([0x42, 0x4d])), "image/bmp");
});
test("reads quoted CSV and converts it into objects", () => {
  assert.deepEqual(parseCsv('name,note\nAda,"hello, world"'), [["name", "note"], ["Ada", "hello, world"]]);
  assert.deepEqual(csvToJson("name,age\nAda,31"), [{ name: "Ada", age: "31" }]);
});
test("turns object JSON into valid quoted CSV", () => {
  assert.equal(jsonToCsv('[{"name":"Ada","note":"say \\"hi\\""}]'), '"name","note"\n"Ada","say ""hi"""');
});
test("does not offer the input image format as an output", () => {
  assert.deepEqual(possibleOutputs("image/png").map(x => x.mime).sort(), ["image/jpeg", "image/webp"]);
  assert.deepEqual(possibleOutputs("image/bmp").map(x => x.mime).sort(), ["image/jpeg", "image/png", "image/webp"]);
});
