import "./style.css";
import { IMAGE_TYPES, detectSignature, extensionOf, possibleOutputs, unavailableOutputs, prettySize, typeFromName, csvToJson, jsonToCsv } from "./formats.js";

const $ = selector => document.querySelector(selector);
const input = $("#file-input"), zone = $("#drop-zone"), analysis = $("#analysis"), processing = $("#processing"), result = $("#result-panel");
let currentFile, detectedType;

let soundsEnabled = true, audioContext;
const soundToggle = $("#sound-toggle");
soundToggle.addEventListener("click", () => {
  soundsEnabled = !soundsEnabled;
  soundToggle.setAttribute("aria-pressed", String(soundsEnabled));
  soundToggle.setAttribute("aria-label", soundsEnabled ? "Turn click sounds off" : "Turn click sounds on");
  $("#sound-label").textContent = soundsEnabled ? "SOUND ON" : "SOUND OFF";
});
document.addEventListener("click", event => {
  if (soundsEnabled && event.target.closest("button, .drop-zone")) playClickSound();
});
function playClickSound() {
  const AudioEngine = window.AudioContext || window.webkitAudioContext;
  if (!AudioEngine) return;
  audioContext ||= new AudioEngine();
  if (audioContext.state === "suspended") audioContext.resume();
  const now = audioContext.currentTime;
  const tone = audioContext.createOscillator();
  const gain = audioContext.createGain();
  tone.type = "sine"; tone.frequency.setValueAtTime(1120, now); tone.frequency.exponentialRampToValueAtTime(690, now + .045);
  gain.gain.setValueAtTime(.0001, now); gain.gain.exponentialRampToValueAtTime(.025, now + .005); gain.gain.exponentialRampToValueAtTime(.0001, now + .055);
  tone.connect(gain); gain.connect(audioContext.destination); tone.start(now); tone.stop(now + .06);
}
$(".converter").addEventListener("pointermove", event => {
  const rect = event.currentTarget.getBoundingClientRect();
  event.currentTarget.style.setProperty("--glow-x", `${event.clientX - rect.left}px`);
  event.currentTarget.style.setProperty("--glow-y", `${event.clientY - rect.top}px`);
});

$("#browse-button").addEventListener("click", () => input.click());
input.addEventListener("change", event => event.target.files[0] && inspect(event.target.files[0]));
zone.addEventListener("click", event => { if (event.target.tagName !== "BUTTON") input.click(); });
zone.addEventListener("keydown", event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); input.click(); } });
["dragenter", "dragover"].forEach(event => zone.addEventListener(event, e => { e.preventDefault(); zone.classList.add("dragging"); }));
["dragleave", "drop"].forEach(event => zone.addEventListener(event, e => { e.preventDefault(); zone.classList.remove("dragging"); }));
zone.addEventListener("drop", event => event.dataTransfer.files[0] && inspect(event.dataTransfer.files[0]));
$("#reset-button").addEventListener("click", reset);

async function inspect(file) {
  currentFile = file; result.classList.add("hidden"); analysis.classList.remove("hidden"); zone.classList.add("compact"); processing.classList.remove("hidden");
  $("#file-name").textContent = file.name; $("#file-meta").textContent = prettySize(file.size);
  $("#file-icon").textContent = extensionOf(file.name).slice(0, 4).toUpperCase() || "FILE";
  $("#processing-text").textContent = "Reading file headers…";
  const bytes = new Uint8Array(await file.slice(0, 16).arrayBuffer());
  await new Promise(resolve => setTimeout(resolve, 520));
  const signatureType = detectSignature(bytes); const claimedType = typeFromName(file);
  detectedType = signatureType || claimedType;
  $("#processing-text").textContent = "Matching conversion paths…";
  await new Promise(resolve => setTimeout(resolve, 380));
  processing.classList.add("hidden"); renderOptions(signatureType, claimedType);
}

function renderOptions(signatureType, claimedType) {
  const options = possibleOutputs(detectedType); const unavailable = unavailableOutputs(detectedType); const warning = $("#warning");
  $("#detected-type").textContent = `${formatName(detectedType)} detected`;
  $("#confidence").textContent = signatureType ? " · file signature verified" : " · detected from filename/type";
  const list = $("#format-list"), unavailableList = $("#unavailable-list"), moreFormats = $("#more-formats"); list.innerHTML = ""; unavailableList.innerHTML = "";
  options.forEach((option, index) => { const button = document.createElement("button"); button.type = "button"; button.className = "format-card"; button.style.setProperty("--i", index); button.innerHTML = `<span class="format-badge">${option.label}</span><span><b>${option.label}</b><small>Ready to convert</small></span><span class="arrow" aria-hidden="true">→</span>`; button.addEventListener("click", () => convert(option)); list.append(button); });
  unavailable.forEach((option, index) => { const card = document.createElement("div"); card.className = "format-card unavailable-card"; card.style.setProperty("--i", index); card.innerHTML = `<span class="format-badge">${option.label}</span><span><b>${option.label}</b><small>${option.reason}</small></span><span class="soon">NOT READY</span>`; unavailableList.append(card); });
  moreFormats.classList.toggle("hidden", unavailable.length === 0);
  warning.classList.toggle("hidden", options.length > 0);
  if (!options.length) warning.textContent = unsupportedMessage(detectedType, claimedType);
  result.classList.remove("hidden");
}

function formatName(type) { return IMAGE_TYPES[type]?.label || ({ "application/json": "JSON", "text/csv": "CSV", "text/plain": "plain text", "text/html": "HTML", "application/pdf": "PDF", "application/zip": "ZIP", "audio/mpeg": "MP3", "audio/ogg": "OGG audio" }[type] || "unknown format"); }
function unsupportedMessage(type) { if (type.startsWith("audio/") || type.startsWith("video/")) return "Audio and video conversions need a media engine such as FFmpeg, which is intentionally not bundled here. This app will not pretend it can convert them."; if (type === "application/pdf" || type === "application/zip") return "This file was identified, but PDF, Office and archive conversion are not available in this browser-only build."; return "OmniConvert cannot verify a safe local conversion path for this file yet. No conversion is offered."; }

async function convert(output) {
  try {
    const source = currentFile.name.replace(/\.[^.]+$/, "") || "converted";
    let blob;
    if (IMAGE_TYPES[detectedType]) blob = await convertImage(currentFile, output.mime);
    else if (detectedType === "text/html") blob = await convertHtml(currentFile, output.mime);
    else blob = await convertText(currentFile, detectedType, output.mime);
    download(blob, `${source}.${output.extension}`);
  } catch (error) { $("#warning").textContent = `Conversion stopped: ${error.message}`; $("#warning").classList.remove("hidden"); }
}
async function convertHtml(file, outputType) {
  const source = await file.text();
  const doc = new DOMParser().parseFromString(source, "text/html");
  doc.querySelectorAll("script,style,link,meta,iframe,object,embed,noscript").forEach(node => node.remove());
  if (outputType === "text/plain") return new Blob([doc.body.innerText || doc.body.textContent || ""], { type: "text/plain;charset=utf-8" });
  if (outputType === "text/markdown") return new Blob([htmlToMarkdown(doc.body)], { type: "text/markdown;charset=utf-8" });
  if (outputType === "application/rtf") return new Blob([htmlToRtf(doc.body)], { type: "application/rtf" });
  if (outputType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") return createDocx(doc.body);
  throw new Error("That HTML output is not available yet.");
}

function htmlToMarkdown(root) {
  const render = node => {
    if (node.nodeType === Node.TEXT_NODE) return node.textContent.replace(/\s+/g, " ");
    if (node.nodeType !== Node.ELEMENT_NODE) return "";
    const body = [...node.childNodes].map(render).join("").trim();
    const tag = node.tagName.toLowerCase();
    if (/^h[1-6]$/.test(tag)) return `${"#".repeat(Number(tag[1]))} ${body}\n\n`;
    if (tag === "p" || tag === "div" || tag === "section" || tag === "article") return `${body}\n\n`;
    if (tag === "li") return `- ${body}\n`;
    if (tag === "strong" || tag === "b") return `**${body}**`;
    if (tag === "em" || tag === "i") return `*${body}*`;
    if (tag === "br") return "\n";
    if (tag === "a") return node.href ? `[${body}](${node.getAttribute("href")})` : body;
    return body;
  };
  return [...root.childNodes].map(render).join("").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim() + "\n";
}

function htmlToRtf(root) {
  const escape = text => text.replace(/[\\{}]/g, "\\$&").replace(/[^\x00-\x7f]/g, char => `\\u${char.charCodeAt(0)}?`);
  const lines = [];
  const walk = node => {
    if (node.nodeType === Node.TEXT_NODE) { const t = node.textContent.replace(/\s+/g, " ").trim(); if (t) lines.push(escape(t)); return; }
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const start = lines.length;
    [...node.childNodes].forEach(walk);
    const tag = node.tagName.toLowerCase();
    if (/^h[1-6]$/.test(tag) && lines.length > start) lines[start] = `\\b\\fs${Math.max(24, 40 - Number(tag[1]) * 2)} ${lines[start]}\\b0\\fs24`;
    if (["p", "div", "li", "h1", "h2", "h3", "h4", "h5", "h6", "br"].includes(tag)) lines.push("\\line");
  };
  [...root.childNodes].forEach(walk);
  return `{\\rtf1\\ansi\\deff0{\\fonttbl{\\f0 Arial;}}\\viewkind4\\uc1\\pard\\f0\\fs24 ${lines.join(" ")}\\par}`;
}

// Minimal standards-compliant DOCX package. The document contains extracted, safe text.
async function createDocx(root) {
  const blocks = [];
  const walk = node => {
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const tag = node.tagName.toLowerCase();
    if (/^h[1-6]$/.test(tag) || ["p", "li", "blockquote", "pre", "td", "th"].includes(tag)) {
      const text = (node.innerText || node.textContent || "").trim();
      if (text) blocks.push({ text, heading: /^h[1-6]$/.test(tag), list: tag === "li" });
      return;
    }
    [...node.children].forEach(walk);
  };
  [...root.children].forEach(walk);
  if (!blocks.length) { const text = (root.innerText || root.textContent || "").trim(); if (text) blocks.push({ text }); }
  const paragraphs = blocks.map(block => {
    const text = xmlEscape(block.text);
    const props = block.heading ? "<w:pPr><w:pStyle w:val=\"Heading1\"/></w:pPr>" : "";
    const bullet = block.list ? "• " : "";
    return `<w:p>${props}<w:r><w:t xml:space="preserve">${xmlEscape(bullet)}${text}</w:t></w:r></w:p>`;
  }).join("");
  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${paragraphs}<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr></w:body></w:document>`;
  const files = [
    ["[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>`],
    ["_rels/.rels", `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`],
    ["word/document.xml", documentXml],
    ["word/_rels/document.xml.rels", `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`],
    ["word/styles.xml", `<?xml version="1.0" encoding="UTF-8"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="22"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/></w:pPr><w:rPr><w:b/><w:sz w:val="32"/></w:rPr></w:style></w:styles>`]
  ];
  return new Blob([zipStore(files)], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
}
function xmlEscape(text) { return text.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;"); }
function zipStore(files) {
  const encoder = new TextEncoder(); const local = []; const central = []; let offset = 0;
  for (const [name, content] of files) {
    const nameBytes = encoder.encode(name), data = encoder.encode(content), crc = crc32(data);
    const header = new Uint8Array(30 + nameBytes.length); const v = new DataView(header.buffer);
    v.setUint32(0, 0x04034b50, true); v.setUint16(4, 20, true); v.setUint16(6, 0, true); v.setUint16(8, 0, true); v.setUint16(10, 0, true); v.setUint16(12, 0, true); v.setUint32(14, crc, true); v.setUint32(18, data.length, true); v.setUint32(22, data.length, true); v.setUint16(26, nameBytes.length, true); v.setUint16(28, 0, true); header.set(nameBytes, 30); local.push(header, data);
    const dir = new Uint8Array(46 + nameBytes.length); const d = new DataView(dir.buffer); d.setUint32(0, 0x02014b50, true); d.setUint16(4, 20, true); d.setUint16(6, 20, true); d.setUint16(8, 0, true); d.setUint16(10, 0, true); d.setUint16(12, 0, true); d.setUint16(14, 0, true); d.setUint32(16, crc, true); d.setUint32(20, data.length, true); d.setUint32(24, data.length, true); d.setUint16(28, nameBytes.length, true); d.setUint16(30, 0, true); d.setUint16(32, 0, true); d.setUint16(34, 0, true); d.setUint16(36, 0, true); d.setUint32(38, 0, true); d.setUint32(42, offset, true); dir.set(nameBytes, 46); central.push(dir); offset += header.length + data.length;
  }
  const centralSize = central.reduce((sum, part) => sum + part.length, 0); const end = new Uint8Array(22); const e = new DataView(end.buffer); e.setUint32(0, 0x06054b50, true); e.setUint16(4, 0, true); e.setUint16(6, 0, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, centralSize, true); e.setUint32(16, offset, true); e.setUint16(20, 0, true); return concatenate([...local, ...central, end]);
}
function concatenate(parts) { const result = new Uint8Array(parts.reduce((total, part) => total + part.length, 0)); let offset = 0; for (const part of parts) { result.set(part, offset); offset += part.length; } return result; }
function crc32(bytes) { let crc = -1; for (const byte of bytes) { crc ^= byte; for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (-(crc & 1) & 0xedb88320); } return (crc ^ -1) >>> 0; }
async function convertImage(file, mime) {
  const image = new Image(); const url = URL.createObjectURL(file);
  try { await new Promise((resolve, reject) => { image.onload = resolve; image.onerror = () => reject(new Error("This image could not be decoded by your browser.")); image.src = url; }); const canvas = document.createElement("canvas"); canvas.width = image.naturalWidth; canvas.height = image.naturalHeight; const ctx = canvas.getContext("2d"); if (mime === "image/jpeg") { ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, canvas.width, canvas.height); } ctx.drawImage(image, 0, 0); return await new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error("Your browser could not encode this output.")), mime, 0.92)); } finally { URL.revokeObjectURL(url); }
}
async function convertText(file, inputType, outputType) { const text = await file.text(); if (outputType === "text/plain") return new Blob([inputType === "application/json" ? JSON.stringify(JSON.parse(text), null, 2) : text], { type: "text/plain;charset=utf-8" }); if (inputType === "text/csv" && outputType === "application/json") return new Blob([JSON.stringify(csvToJson(text), null, 2)], { type: "application/json" }); if ((inputType === "application/json" || inputType === "text/plain") && outputType === "text/csv") return new Blob([jsonToCsv(text)], { type: "text/csv;charset=utf-8" }); if (inputType === "text/plain" && outputType === "application/json") { JSON.parse(text); return new Blob([JSON.stringify(JSON.parse(text), null, 2)], { type: "application/json" }); } throw new Error("That conversion path is not available for this content."); }
function download(blob, name) { const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = name; document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(link.href), 1000); }
function reset() { input.value = ""; analysis.classList.add("hidden"); zone.classList.remove("compact"); $("#warning").classList.add("hidden"); $("#more-formats").open = false; }
