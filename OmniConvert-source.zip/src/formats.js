export const IMAGE_TYPES = {
  "image/png": { label: "PNG", extension: "png" },
  "image/jpeg": { label: "JPEG", extension: "jpg" },
  "image/webp": { label: "WebP", extension: "webp" },
  "image/bmp": { label: "BMP", extension: "bmp" }
};
// Canvas can decode BMP in many browsers, but it has no reliable BMP encoder.
// Only these MIME types are safe to offer as downloadable output.
export const CANVAS_OUTPUT_TYPES = ["image/png", "image/jpeg", "image/webp"];

const signatures = [
  { bytes: [0x89, 0x50, 0x4e, 0x47], type: "image/png" },
  { bytes: [0xff, 0xd8, 0xff], type: "image/jpeg" },
  { bytes: [0x52, 0x49, 0x46, 0x46], type: "image/webp", test: bytes => String.fromCharCode(...bytes.slice(8, 12)) === "WEBP" },
  { bytes: [0x42, 0x4d], type: "image/bmp" },
  { bytes: [0x25, 0x50, 0x44, 0x46], type: "application/pdf" },
  { bytes: [0x50, 0x4b, 0x03, 0x04], type: "application/zip" },
  { bytes: [0x49, 0x44, 0x33], type: "audio/mpeg" },
  { bytes: [0x4f, 0x67, 0x67, 0x53], type: "audio/ogg" }
];

export function detectSignature(bytes) {
  for (const signature of signatures) {
    const matches = signature.bytes.every((value, i) => bytes[i] === value);
    if (matches && (!signature.test || signature.test(bytes))) return signature.type;
  }
  return null;
}

export function extensionOf(name) { return name.split(".").pop()?.toLowerCase() || ""; }
export function prettySize(size) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / 1024 / 1024).toFixed(1)} MB`;
}

export function possibleOutputs(type) {
  if (IMAGE_TYPES[type]) return CANVAS_OUTPUT_TYPES.filter(mime => mime !== type).map(mime => ({ mime, ...IMAGE_TYPES[mime] }));
  if (type === "text/html") return [
    { mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", label: "Word DOCX", extension: "docx" },
    { mime: "text/plain", label: "Plain text", extension: "txt" },
    { mime: "application/rtf", label: "Rich Text", extension: "rtf" },
    { mime: "text/markdown", label: "Markdown", extension: "md" }
  ];
  if (type === "application/json") return [{ mime: "text/plain", label: "Text", extension: "txt" }, { mime: "text/csv", label: "CSV", extension: "csv" }];
  if (type === "text/csv") return [{ mime: "application/json", label: "JSON", extension: "json" }, { mime: "text/plain", label: "Text", extension: "txt" }];
  if (type === "text/plain") return [{ mime: "application/json", label: "JSON", extension: "json" }, { mime: "text/csv", label: "CSV", extension: "csv" }];
  return [];
}

export function unavailableOutputs(type) {
  if (type === "text/html") return [
    { label: "PDF", reason: "PDF export needs a print or PDF rendering engine." },
    { label: "PNG / JPEG", reason: "Page screenshots need a browser rendering engine." },
    { label: "EPUB", reason: "EPUB packaging is not included yet." },
    { label: "Excel XLSX", reason: "Spreadsheet generation is not included yet." }
  ];
  if (IMAGE_TYPES[type]) return ["GIF", "TIFF", "AVIF", "SVG"].map(label => ({ label, reason: "This browser build has no reliable encoder for this format." }));
  if (["text/plain", "text/csv", "application/json"].includes(type)) return ["PDF", "Word DOCX", "Excel XLSX"].map(label => ({ label, reason: "A document or spreadsheet generator is required for this output." }));
  if (type.startsWith("audio/") || type.startsWith("video/")) return ["MP3", "WAV", "AAC", "MP4", "WebM"].map(label => ({ label, reason: "Audio/video conversion needs FFmpeg or another media engine." }));
  if (type === "application/pdf") return ["Word DOCX", "PNG", "JPEG", "Text"].map(label => ({ label, reason: "PDF parsing and rendering tools are not included yet." }));
  return [];
}

export function typeFromName(file) {
  const ext = extensionOf(file.name);
  if (["txt", "md", "log"].includes(ext)) return "text/plain";
  if (ext === "json") return "application/json";
  if (ext === "csv") return "text/csv";
  if (["html", "htm"].includes(ext)) return "text/html";
  return file.type || "application/octet-stream";
}

export function parseCsv(text) {
  const rows = []; let row = [], value = "", quoted = false;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (char === '"' && quoted && text[i + 1] === '"') { value += '"'; i++; }
    else if (char === '"') quoted = !quoted;
    else if (char === "," && !quoted) { row.push(value); value = ""; }
    else if ((char === "\n" || char === "\r") && !quoted) { if (char === "\r" && text[i + 1] === "\n") i++; row.push(value); if (row.some(cell => cell !== "")) rows.push(row); row = []; value = ""; }
    else value += char;
  }
  if (quoted) throw new Error("The CSV has an unclosed quoted value.");
  row.push(value); if (row.some(cell => cell !== "")) rows.push(row);
  return rows;
}

export function csvToJson(text) {
  const rows = parseCsv(text); if (!rows.length) return [];
  const headers = rows[0];
  return rows.slice(1).map(row => Object.fromEntries(headers.map((header, i) => [header || `column_${i + 1}`, row[i] ?? ""])));
}
export function jsonToCsv(text) {
  const data = JSON.parse(text); const rows = Array.isArray(data) ? data : [data];
  if (!rows.every(row => row && typeof row === "object" && !Array.isArray(row))) throw new Error("JSON to CSV needs an object or an array of objects.");
  const keys = [...new Set(rows.flatMap(Object.keys))]; const escape = value => `"${String(value ?? "").replaceAll('"', '""')}"`;
  return [keys.map(escape).join(","), ...rows.map(row => keys.map(key => escape(row[key])).join(","))].join("\n");
}
