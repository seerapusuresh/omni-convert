import { defineConfig } from "vite";

// Relative asset paths allow the same build to work on GitHub Pages and any static host.
export default defineConfig({ base: "./" });
